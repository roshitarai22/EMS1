package com.flp.ems.view;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Scanner;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.flp.ems.service.EmployeeServiceImpl;



/**
 * Servlet implementation class UserServlet
 */
@WebServlet("/UserServlet")
public class UserServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	 private static final String ACTION_KEY = "actionName";
	    private static final String VIEW_EMPLOYEE_LIST_ACTION = "viewEmployeeList";
	    private static final String ADD_EMPLOYEE_ACTION = "addEmployee";
	    private static final String UPDATE_EMPLOYEE_ACTION = "updateEmployee";
	    private static final String SEARCH_EMPLOYEE_ACTION = "searchEmployee";
	    private static final String DELETE_EMPLOYEE_ACTION = "deleteEmployee";
	    private static final String ERROR_KEY = "errorMessage";
       
    
	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		try {
			processRequest(request, response);
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		try {
			processRequest(request, response);
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	  protected void processRequest(HttpServletRequest request, HttpServletResponse response)
	            throws ServletException, IOException, ParseException, SQLException, ClassNotFoundException {
	        String actionName = request.getParameter(ACTION_KEY);
	      
	       
	        if(VIEW_EMPLOYEE_LIST_ACTION.equals(actionName))
	        {            
	        	EmployeeServiceImpl empserimpl = new EmployeeServiceImpl();
	        	ArrayList<String> temp2 = empserimpl.getAllEmployee();
	    		    		
	    		PrintWriter out =response.getWriter();
	    		out.println("<html><body>");
	    		
	    		if(temp2 !=null)
	    		{
	    			out.println("<table border='1'>");
	    			for(String vals : temp2)
	    			{
	    				out.println("<tr>");
	    				out.println("<td>" + vals + "</td>");
	    				out.println("</tr>");
	    			}
	    			out.println("</table>");
	    		}
	    		else
	    			out.println("No employee exist!");
	    			
	    		
	    			out.println("</body></html>");
				
	        }
	        else if( ADD_EMPLOYEE_ACTION.equals(actionName))
	        {
	        	HashMap<String, String> create = new HashMap<String, String>();
	        	  EmployeeServiceImpl empserimpl = new EmployeeServiceImpl();
	    		String Name;
	    		String Phone_Number;
	    		String Address;
	    		String dob;
	    		String doj;
	    		String Kin_id;
	    		String Email_id;
	    		String Depart_id;
	    		String Role_id;
	    		String Project_id;

	    		// NAME
	    		Name = request.getParameter("NAME");
	    		create.put("Name", Name);

	    		// Address
	    		Address = request.getParameter("ADD");
	    		create.put("Address", Address);
	    		
	    		// DOB
	    		dob = request.getParameter("DOB");
	    		create.put("DOB", dob);
	    		
	    		// DOJ
	      		doj = request.getParameter("DOJ");
	    		create.put("DOJ", doj);

	    		//Phn_num
	    		Phone_Number = request.getParameter("PHNNUM");
	    		create.put("Phone Number", Phone_Number);
	    		
	    		// DEPART_ID
	    		Depart_id = request.getParameter("DEPARTID");
	    		create.put("DEPARTMENT_ID", Depart_id);
	    		
	    		// ROLE_ID
	    		Role_id = request.getParameter("ROLEID");
	    		create.put("ROLE_ID", Role_id);
	    		
	    		// PROJECT_ID
	    		Project_id = request.getParameter("PROID");
	    		create.put("PROJECT_ID", Project_id);
	    		
	    		// KIN_ID
	    		String[] name = Name.split(" ");
	    		Kin_id = name[0].substring(0, 3).toLowerCase() + name[1].substring(0, 3).toUpperCase();
	    		create.put("KIN_ID", Kin_id);
	    	
	    		// EMAIL_ID
	    		Email_id = Kin_id + "@" + "barclaycard.co.uk";
	    		create.put("EMAIL_ID", Email_id);
	    	
	    		empserimpl.AddEmployee(create);
	    		ArrayList<HashMap<String, String>> prodArrayList = new ArrayList<HashMap<String, String>>();
	    		prodArrayList.add(create);
	    		PrintWriter out =response.getWriter();
	    		out.println("<html><body>");
	    		
	    		if(prodArrayList !=null)
	    		{
	    			out.println("<table border='1'>");
	    			for(HashMap<String, String> vals : prodArrayList)
	    			{
	    				out.println("<tr>");
	    				out.println("<td>" + create.get("Name")+ "</td>");
	    				out.println("<td>" + create.get("EMAIL_ID")+ "</td>");
	    				out.println("</tr>");
	    			}
	    			out.println("</table>");
	    		}
	    		else
	    			out.println("No employee exist!");
	    			
	    		
	    			out.println("</body></html>");
	    		
	        }  
	        else if(UPDATE_EMPLOYEE_ACTION.equals(actionName))
	        {
	        	
	        	/*public void ModifyEmployee() throws ParseException, IOException, SQLException {

	        		HashMap<String, String> modify = new HashMap<String, String>();
	        		  EmployeeServiceImpl empserimpl = new EmployeeServiceImpl();String Name;
	        		int EmployeeId;
	        		String Phone_Number;
	        		String Address;
	        		String dob, doj;
	        		String Depart_id, Role_id, Project_id;
	        		System.out.println("Enter your employee id");

	        		EmployeeId = temp.nextInt();
	        		if (empserimpl.SearchEmployee(EmployeeId) != null) {

	        			System.out.println("Enter your name");
	        			temp.nextLine();
	        			Name = temp.nextLine();
	        			modify.put("Name", Name);

	        			System.out.println("Enter your contact number");
	        			Phone_Number = temp.nextLine();
	        			modify.put("Phone Number", Phone_Number);

	        			System.out.println("Enter your address");
	        			Address = temp.nextLine();
	        			modify.put("Address", Address);

	        			// DOB
	        			System.out.println("Enter you Date of Birth(dd/mm/yyyy)");
	        			dob = temp.nextLine();
	        			if (!dob.equals("")) {
	        				DateFormat df = new SimpleDateFormat("dd/MM/yyyy");
	        				Calendar cal = Calendar.getInstance();
	        				Date date = df.parse(dob);
	        				modify.put("DOB", dob);
	        			}
	        			else{modify.put("DOB","" );}
	        			// DOJ
	        			System.out.println("Enter you Date of Joining(dd/mm/yyyy)");
	        			doj = temp.nextLine();
	        			if (!doj.equals("")) {
	        				DateFormat df1 = new SimpleDateFormat("dd/MM/yyyy");
	        				Calendar cal1 = Calendar.getInstance();
	        				Date date1 = df1.parse(doj);
	        				modify.put("DOJ", doj);
	        			}
	        			else{modify.put("DOJ","" );}
	        			// DEPART_ID
	        			System.out.println("Enter your department id");
	        			Depart_id = temp.nextLine();
	        			modify.put("DEPARTMENT_ID", Depart_id);

	        			// ROLE_ID
	         			System.out.println("Enter your role id");
	        			Role_id = temp.nextLine();
	        			modify.put("ROLE_ID", Role_id);

	        			// PROJECT_ID
	        			System.out.println("Enter your project id");
	        			Project_id = temp.nextLine();
	        			modify.put("PROJECT_ID", Project_id);

	        		}
	        		empserimpl.ModifyEmployee(modify, EmployeeId);*/
	        }        
	        else if(SEARCH_EMPLOYEE_ACTION.equals(actionName))
	        {
	        	PrintWriter out = response.getWriter();
	        	EmployeeServiceImpl empserimpl = new EmployeeServiceImpl();
	    		int id = Integer.parseInt(request.getParameter("EmpID"));
	    		String employeeDetail = empserimpl.SearchEmployee(id);
	    		if (employeeDetail!= null) 
	    			out.println(employeeDetail);
	    			else
	    		 out.println("NO SUCH EMPLOYEE EXISTS");
	    		
	    		
	            
	        }  
	        else if(DELETE_EMPLOYEE_ACTION.equals(actionName))
	        {
	        	EmployeeServiceImpl empserimpl = new EmployeeServiceImpl();
	    		int id =Integer.parseInt(request.getParameter("EmpID"));
	    		boolean res =false;
	    		res=empserimpl.RemoveEmployee(id);
	        	PrintWriter out = response.getWriter();
	        	if(res!=false)
	    		{
	    			out.println("EMPLOYEE DELETED SUCCESSFULLY");
	    		}
	        	else
	        		out.println("FALSE REQUEST");
	            
	        }                    
	        else
	        {
	            String errorMessage = "[" + actionName + "] is not a valid action.";
	            request.setAttribute(ERROR_KEY, errorMessage);
	        }


	        //TODO 9 Use appropriate Servlet API to forward the request to 
			//appropriate destination page set in above if else blocks depending on action.
	        
	    }
	
}

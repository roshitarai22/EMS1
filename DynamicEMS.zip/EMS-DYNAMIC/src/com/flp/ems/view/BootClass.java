package com.flp.ems.view;

import java.io.IOException;
import java.sql.SQLException;
import java.text.ParseException;
import java.util.Scanner;

public class BootClass {

	public static void main(String[] args) throws ParseException, IOException, SQLException, ClassNotFoundException {

		System.out.println("What operation you want to perform??");
		menuSelection();

	}

	public static void menuSelection() throws ParseException, IOException, SQLException, ClassNotFoundException {

		while (true) {
			int choice;

			System.out.println("1.) Add a new Employee." + "\n" + "2.) Update the existing information of an Employee."
					+ "\n" + "3.) Delete an Employee." + "\n" + "4.) Search an Employee usin its idd." + "\n"
					+ "5.) View all Employee" + "\n" + "6.) Exit");
			Scanner UC = new Scanner(System.in);
			choice = UC.nextInt();
			UserInteraction ui = new UserInteraction();

			int i = choice;

			switch (i) {
			case 1:
				ui.AddEmployee();
				break;

			case 2:
				ui.ModifyEmployee();
				break;

			case 3:
				ui.RemoveEmplooye();
				
				break;

			case 4:
				ui.SearchEmployee();
				break;

			case 5:
				ui.getAllEmployee();
				break;

			case 6:
				System.exit(0);
				break;
			default:
				System.out.println("Input is not recognized");

			}
			// UC.close();
		}
	}

}

package com.flp.ems.view;


import com.flp.ems.domain.Employee;
import com.flp.ems.service.EmployeeServiceImpl;

import java.util.*;
import java.io.IOException;
import java.sql.SQLException;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;


public class UserInteraction {

	Scanner temp = new Scanner(System.in);
	EmployeeServiceImpl empserimpl = new EmployeeServiceImpl();

	public void AddEmployee() throws ParseException, IOException, SQLException, ClassNotFoundException {

		HashMap<String, String> create = new HashMap<String, String>();

		String Name;
		long Phone_Number;
		String Address;
		String dob;
		String doj;
		String Kin_id;
		String Email_id;
		int Depart_id;
		int Role_id;
		int Project_id;

		// NAME
		System.out.println("Enter your name");
		Name = temp.nextLine();
		create.put("Name", Name);
	//	Validate.validateName(Name);

		System.out.println("Enter your contact number");
		Phone_Number = temp.nextLong();
		temp.nextLine();
		create.put("Phone Number", String.valueOf(Phone_Number));

		// Address
		System.out.println("Enter your address");
		Address = temp.nextLine();
		create.put("Address", Address);

		// DOB
		System.out.println("Enter you Date of Birth(dd/mm/yyyy)");
		dob = temp.next();
		DateFormat df = new SimpleDateFormat("dd/MM/yyyy");
		Calendar cal = Calendar.getInstance();
		Date date = df.parse(dob);
		create.put("DOB", dob);

		// DOJ
		System.out.println("Enter you Date of Joining(dd/mm/yyyy)");
		doj = temp.next();
		DateFormat df1 = new SimpleDateFormat("dd/MM/yyyy");
		Calendar cal1 = Calendar.getInstance();
		Date date1 = df1.parse(doj);
		create.put("DOJ", doj);

		// DEPART_ID
		System.out.println("Enter your department id");
		Depart_id = temp.nextInt();
		create.put("DEPARTMENT_ID", String.valueOf(Depart_id));

		// ROLE_ID
		System.out.println("Enter your role id");
		Role_id = temp.nextInt();
		create.put("ROLE_ID", String.valueOf(Role_id));

		// PROJECT_ID
		System.out.println("Enter your project id");
		Project_id = temp.nextInt();
		create.put("PROJECT_ID", String.valueOf(Project_id));

		// KIN_ID
		String[] name = Name.split(" ");
		Kin_id = name[0].substring(0, 3).toLowerCase() + name[1].substring(0, 3).toUpperCase();
		create.put("KIN_ID", Kin_id);

		// EMAIL_ID
		Email_id = Kin_id + "@" + "barclaycard.co.uk";
		create.put("EMAIL_ID", Email_id);

		empserimpl.AddEmployee(create);

	}

	public void ModifyEmployee() throws ParseException, IOException, SQLException, ClassNotFoundException {

		HashMap<String, String> modify = new HashMap<String, String>();
		String Name;
		int EmployeeId;
		String Phone_Number;
		String Address;
		String dob, doj;
		String Depart_id, Role_id, Project_id;
		System.out.println("Enter your employee id");

		EmployeeId = temp.nextInt();
		if (empserimpl.SearchEmployee(EmployeeId) != null) {

			System.out.println("Enter your name");
			temp.nextLine();
			Name = temp.nextLine();
			modify.put("Name", Name);

			System.out.println("Enter your contact number");
			Phone_Number = temp.nextLine();
			modify.put("Phone Number", Phone_Number);

			System.out.println("Enter your address");
			Address = temp.nextLine();
			modify.put("Address", Address);

			// DOB
			System.out.println("Enter you Date of Birth(dd/mm/yyyy)");
			dob = temp.nextLine();
			if (!dob.equals("")) {
				/*DateFormat df = new SimpleDateFormat("dd/MM/yyyy");
				Calendar cal = Calendar.getInstance();
				Date date = df.parse(dob);*/
				modify.put("DOB", dob);
			}
			else{modify.put("DOB","" );}
			// DOJ
			System.out.println("Enter you Date of Joining(dd/mm/yyyy)");
			doj = temp.nextLine();
			if (!doj.equals("")) {
				/*DateFormat df1 = new SimpleDateFormat("dd/MM/yyyy");
				Calendar cal1 = Calendar.getInstance();
				Date date1 = df1.parse(doj);*/
				modify.put("DOJ", doj);
			}
			else{modify.put("DOJ","" );}
			// DEPART_ID
			System.out.println("Enter your department id");
			Depart_id = temp.nextLine();
			modify.put("DEPARTMENT_ID", Depart_id);

			// ROLE_ID
			System.out.println("Enter your role id");
			Role_id = temp.nextLine();
			modify.put("ROLE_ID", Role_id);

			// PROJECT_ID
			System.out.println("Enter your project id");
			Project_id = temp.nextLine();
			modify.put("PROJECT_ID", Project_id);

		}
		empserimpl.ModifyEmployee(modify, EmployeeId);

	}

	public void RemoveEmplooye() throws IOException, SQLException, ClassNotFoundException {
		System.out.println("Enter the id of the employee to be removed");
		int id = temp.nextInt();
		empserimpl.RemoveEmployee(id);
		return;
	}

	public void SearchEmployee() throws IOException, SQLException, ClassNotFoundException {

		System.out.println("Enter the id of the employee to be searched");
		int id = temp.nextInt();
		String employeeDetail = empserimpl.SearchEmployee(id);
		if (employeeDetail == null) {
			System.out.println("Employeee not found");
		}
		System.out.println(employeeDetail);
	}

	public void getAllEmployee() throws IOException, SQLException, ClassNotFoundException {
		ArrayList<String> temp2 = empserimpl.getAllEmployee();
		if (temp2 == null) {
			System.out.println("No employee exist");
		} else {

			for (String str : temp2) {
				System.out.println(str);
			}
		}
	}

}

package com.flp.ems.dao;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import com.flp.ems.domain.Employee;

public interface IemployeeDao {

	Employee emp = new Employee(null, null, 0, null, null, null, null, 0, 0, 0);
	public void AddEmployee(Employee emp) throws IOException, SQLException, ClassNotFoundException;
	public void ModifyEmployee(Employee emp) throws FileNotFoundException, IOException, SQLException;
	public void RemoveEmployee(int id) throws FileNotFoundException, IOException, SQLException, ClassNotFoundException;
	public Employee SearchEmployee(int id) throws FileNotFoundException, IOException, SQLException, ClassNotFoundException;
	public ArrayList<Employee> getAllEmployee() throws FileNotFoundException, IOException, SQLException, ClassNotFoundException;
}

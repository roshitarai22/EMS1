/*package com.flp.ems.dao;

import java.util.ArrayList;
//import java.util.HashMap;

import com.flp.ems.domain.Employee;

public class EmployeeDaoImplForList implements IemployeeDao {

	static ArrayList<Employee> temp = new ArrayList<>();

	public void AddEmployee(Employee e) {
		temp.add(e);
		for (Employee emp : temp)
			System.out.println(emp);

	}

	public void ModifyEmployee(Employee emp) {
		int id= emp.getEmployeeId();
		id--;
		temp.set(id, emp);
		
		

	}

	public void RemoveEmployee(int id) {

		Integer id1 = id;
		int index = -1;
		for (Employee e : temp) {
			{
				if (id1.equals(e.getEmployeeId()))
					index = temp.indexOf(e);
				break;
			}
		}
		if (index == -1) {
			System.out.println("Employee with such employee id does not exist,wrong input1");
			return;
		}
		temp.remove(index);
		System.out.println("Employee is successfully remove!");

	}

	public Employee SearchEmployee(int id) {
		Integer id1 = id;
		for (Employee e : temp) {
			if (id1.equals(e.getEmployeeId())) {
				return e;
			}
		}
		return null;
	}

	public ArrayList<Employee> getAllEmployee() {
		if(temp == null)
		{
			temp.add(null);
		}
		return temp;
	}

}
*/
package com.flp.ems.dao;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.Date;
//import java.util.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Properties;
import com.flp.ems.domain.Employee;

public class EmployeeDaoImplForDB implements IemployeeDao {

	@Override
	public void AddEmployee(Employee emp) throws IOException, SQLException, ClassNotFoundException {

		/*Properties prop = new Properties();
		FileInputStream fln = new FileInputStream("/dbDetails.properties");
		prop.load(fln);*/
		ClassLoader classLoader = Thread.currentThread().getContextClassLoader();
		InputStream input = classLoader.getResourceAsStream("/dbDetails.properties");
		Properties prop = new Properties();
		prop.load(input);

		String driver = prop.getProperty("jdbc.driver");
		 Class.forName(driver);

		String url = prop.getProperty("jdbc.url");
		Connection dbConnection;

		dbConnection = DriverManager.getConnection(url);

		System.out.println(dbConnection != null);
		String insertQuery = prop.getProperty("jdbc.query.insert");

		try (PreparedStatement insertStatement = dbConnection.prepareStatement(insertQuery)) {
			insertStatement.setString(1, emp.getName());
			insertStatement.setString(2, emp.getKin_id());
			insertStatement.setString(3, emp.getEmail_id());
			insertStatement.setLong(4, emp.getPhoneNumber());
			insertStatement.setDate(5, new Date(emp.getDOB().getTime()));
			insertStatement.setDate(6, new Date(emp.getDOJ().getTime()));
			insertStatement.setString(7, emp.getAddress());
			insertStatement.setInt(8, emp.getDepartmentId());
			insertStatement.setInt(9, emp.getProjectId());
			insertStatement.setInt(10, emp.getRoleId());
			insertStatement.executeUpdate();

		}

	}

	@Override
	public void ModifyEmployee(Employee e) throws IOException, SQLException {
		Properties prop = new Properties();
		FileInputStream fln = new FileInputStream("/dbDetails.properties");
		prop.load(fln);

		String driver = prop.getProperty("jdbc.driver");

		String url = prop.getProperty("jdbc.url");
		Connection dbConnection;

		dbConnection = DriverManager.getConnection(url);
		System.out.println(dbConnection != null);
		String selectQuery = prop.getProperty("jdbc.query.select");
		try(PreparedStatement selectStatement = dbConnection.prepareStatement(selectQuery,ResultSet.TYPE_FORWARD_ONLY,
				ResultSet.CONCUR_UPDATABLE))
		{
		selectStatement.setInt(1,e.getEmployeeId());	
		ResultSet rs = selectStatement.executeQuery();
		
		
		rs.next();
		rs.updateString(2, e.getName());
		rs.updateLong(5, e.getPhoneNumber());
		rs.updateDate(6, new Date(e.getDOB().getTime()));
		rs.updateDate(7, new Date(e.getDOJ().getTime()));
		rs.updateString(8, e.getAddress());
		rs.updateInt(9, e.getDepartmentId());
		rs.updateInt(10, e.getProjectId());
		rs.updateInt(11, e.getRoleId());
		rs.updateRow();
		}
	}

	@Override
	public void RemoveEmployee(int id) throws IOException, SQLException, ClassNotFoundException {
		/*Properties prop = new Properties();
		FileInputStream fln = new FileInputStream("/dbDetails.properties");
		prop.load(fln);

		String driver = prop.getProperty("jdbc.driver");
*/
		ClassLoader classLoader = Thread.currentThread().getContextClassLoader();
		InputStream input = classLoader.getResourceAsStream("/dbDetails.properties");
		Properties prop = new Properties();
		prop.load(input);

		String driver = prop.getProperty("jdbc.driver");
		 Class.forName(driver);
		String url = prop.getProperty("jdbc.url");
		Connection dbConnection;

		dbConnection = DriverManager.getConnection(url);
		System.out.println(dbConnection != null);
		String deleteQuery = prop.getProperty("jdbc.query.delete");
		try (PreparedStatement deleteStatement = dbConnection.prepareStatement(deleteQuery)) {
			deleteStatement.setInt(1, id);

			deleteStatement.executeUpdate();

		}

	}

	@Override
	public Employee SearchEmployee(int id) throws IOException, SQLException, ClassNotFoundException {
		Employee emp;
		/*Properties prop = new Properties();
		FileInputStream fln = new FileInputStream("/dbDetails.properties");
		prop.load(fln);

		String driver = prop.getProperty("jdbc.driver");
*/
		ClassLoader classLoader = Thread.currentThread().getContextClassLoader();
		InputStream input = classLoader.getResourceAsStream("/dbDetails.properties");
		Properties prop = new Properties();
		prop.load(input);

		String driver = prop.getProperty("jdbc.driver");
		 Class.forName(driver);
		String url = prop.getProperty("jdbc.url");
		Connection dbConnection;

		dbConnection = DriverManager.getConnection(url);

		System.out.println(dbConnection != null);
		String searchQuery = prop.getProperty("jdbc.query.select");
		try (PreparedStatement searchStatement = dbConnection.prepareStatement(searchQuery)) {

			searchStatement.setInt(1, id);
			ResultSet rs = searchStatement.executeQuery();
			if (rs == null) {
				return null;
			} else {
				rs.next();
				emp = new Employee(rs.getInt(1), rs.getString(2), rs.getString(3), rs.getString(4), rs.getLong(5),
						rs.getDate(6), rs.getDate(7), rs.getString(8), rs.getInt(9), rs.getInt(10), rs.getInt(11));
				return emp;
			}
		}
	}

	@Override
	public ArrayList<Employee> getAllEmployee() throws IOException, SQLException, ClassNotFoundException {

		ArrayList<Employee> temp = new ArrayList<>();
		Employee emp = null;
		/*Properties prop = new Properties();
		FileInputStream fln = new FileInputStream("/dbDetails.properties");
		prop.load(fln);*/
		ClassLoader classLoader = Thread.currentThread().getContextClassLoader();
		InputStream input = classLoader.getResourceAsStream("/dbDetails.properties");
		Properties prop = new Properties();
		prop.load(input);

		String driver = prop.getProperty("jdbc.driver");
		 Class.forName(driver);
		

		String url = prop.getProperty("jdbc.url");
		Connection dbConnection;
		dbConnection = DriverManager.getConnection(url);
		System.out.println(dbConnection != null);
		String selectQuery = prop.getProperty("jdbc.query.selectAll");
		try (PreparedStatement selectStatement = dbConnection.prepareStatement(selectQuery)) {

			ResultSet rs = selectStatement.executeQuery();
			while (rs.next()) {
				
				temp.add(new Employee(rs.getInt(1), rs.getString(2), rs.getString(3), rs.getString(4), rs.getLong(5), rs.getDate(6), rs.getDate(7), rs.getString(8), rs.getInt(9), rs.getInt(10), rs.getInt(11)));
 
				
			}

		}

		return temp;
	}

}

package com.flp.ems.service;

import java.io.IOException;
import java.sql.SQLException;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;

import com.flp.ems.dao.EmployeeDaoImplForDB;

import com.flp.ems.domain.Employee;

public class EmployeeServiceImpl implements IEmployeeService {

	EmployeeDaoImplForDB edifl = new EmployeeDaoImplForDB();

	public void AddEmployee(HashMap<String, String> create) throws ParseException, IOException, SQLException, ClassNotFoundException {
		String dateTmp = create.get("DOB");
		Date birthDate, joinDate;
		DateFormat df1 = new SimpleDateFormat("yyyy-MM-dd");
		// Calendar cal1 = Calendar.getInstance();
		birthDate = df1.parse(dateTmp);
		joinDate = df1.parse(create.get("DOJ"));
		Employee temp = new Employee(create.get("Name"), create.get("Address"),
				Long.parseLong(create.get("Phone Number")), birthDate, joinDate, create.get("KIN_ID"),
				create.get("EMAIL_ID"), Integer.parseInt(create.get("PROJECT_ID")),
				Integer.parseInt(create.get("ROLE_ID")), Integer.parseInt(create.get("DEPARTMENT_ID")));
		edifl.AddEmployee(temp);
	}

	public void ModifyEmployee(HashMap<String, String> modify, int id)
			throws ParseException, IOException, SQLException, ClassNotFoundException {
		String dateTmp = modify.get("DOB");
		String dojtmp = modify.get("DOJ");
		Date birthDate = null, joinDate = null;
		DateFormat df1 = new SimpleDateFormat("yyyy-MM-dd");
		if (!dateTmp.equals("")) {
			birthDate = df1.parse(dateTmp);
		}
		if (!dojtmp.equals("")) {
			joinDate = df1.parse(dojtmp);
		}

		Employee emp = edifl.SearchEmployee(id);
		if (modify.get("Name").length() != 0) {
			emp.setName(modify.get("Name"));
		}
		if (modify.get("Phone Number").length() != 0) {
			emp.setPhoneNumber(Long.parseLong(modify.get("Phone Number")));
		}
		if (modify.get("Address").length() != 0) {
			emp.setAddress(modify.get("Address"));
		}
		if (modify.get("DOB").length() != 0) {
			emp.setDOB(birthDate);
		}
		if (modify.get("DOJ").length() != 0) {
			emp.setDOJ(joinDate);
		}
		if (modify.get("DEPARTMENT_ID").length() != 0) {
			emp.setDepartmentId(Integer.parseInt(modify.get("DEPARTMENT_ID")));
		}
		if (modify.get("ROLE_ID").length() != 0) {
			emp.setRoleId(Integer.parseInt(modify.get("ROLE_ID")));
		}
		if (modify.get("PROJECT_ID").length() != 0) {
			emp.setProjectId(Integer.parseInt(modify.get("PROJECT_ID")));
		}
		edifl.ModifyEmployee(emp);

	}

	public boolean RemoveEmployee(int id) throws IOException, SQLException, ClassNotFoundException {
		edifl.RemoveEmployee(id);

		return true;
	}

	public String SearchEmployee(int id) throws IOException, SQLException, ClassNotFoundException {
		Employee emp = edifl.SearchEmployee(id);
		if (emp == null) {
			return null;
		}
		String empStr = emp.getName() + " " + emp.getEmployeeId() + " " + emp.getAddress();
		return empStr;
	}

	public ArrayList<String> getAllEmployee() throws IOException, SQLException, ClassNotFoundException {
		ArrayList<Employee> emp = edifl.getAllEmployee();
		ArrayList<String> temp1 = new ArrayList<>();
		if (emp == null) {
			temp1.add(null);
		}
		for (Employee e1 : emp) {
			String str = e1.toString();
			temp1.add(str);
		}
		return temp1;
	}

}

package com.flp.ems.service;

import java.io.IOException;
import java.sql.SQLException;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.HashMap;

import com.flp.ems.domain.Employee;

public interface IEmployeeService {
	
	public void AddEmployee(HashMap<String, String> create) throws IOException, SQLException, ParseException, ClassNotFoundException;
	public void ModifyEmployee(HashMap<String,String> modify,int id) throws ParseException, IOException, SQLException, ClassNotFoundException;
	public boolean RemoveEmployee(int id) throws IOException, SQLException, ClassNotFoundException;
	public String SearchEmployee(int id) throws IOException, SQLException, ClassNotFoundException;
	public ArrayList<String> getAllEmployee() throws IOException, SQLException, ClassNotFoundException;
	

}

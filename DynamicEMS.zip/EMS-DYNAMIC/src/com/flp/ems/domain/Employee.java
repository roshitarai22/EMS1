package com.flp.ems.domain;

import java.util.Date;

import com.flp.ems.service.EmployeeServiceImpl;

public class Employee {

	String Name;
	String Address;
	String Kin_id;
	String Email_id;
	int EmployeeId;
	long PhoneNumber;
	int DepartmentId;
	int RoleId;
	int ProjectId;
	Date DOJ, DOB;
	static int count = 0;

	public Employee(int empid, String name, String kinid, String emailid, long phn, Date dob, Date doj, String address,
			int departid,int proid, int roleid) {
			this.EmployeeId = empid;
			this.Name = name;
			this.Kin_id = kinid;
			this.Email_id = emailid;
			this.PhoneNumber = phn;
			this.DOB = dob;
			this.DOJ = doj;
			this.Address = address;
			this.ProjectId = proid;
			this.RoleId = roleid;
			this.DepartmentId = departid;
			
		
	}

	public Employee(String name, String address, long phn, Date dob, Date doj, String kinid, String emailid, int proid,
			int roleid, int departid) {
		this.Name = name;
		this.Address = address;
		this.PhoneNumber = phn;
		this.DOB = dob;
		this.DOJ = doj;
		this.Kin_id = kinid;
		this.Email_id = emailid;
		this.ProjectId = proid;
		this.RoleId = roleid;
		this.DepartmentId = departid;
		// this.EmployeeId = count++;

	}

	
	public String getKin_id() {
		return Kin_id;
	}

	public void setKin_id(String kin_id) {
		Kin_id = kin_id;
	}

	public String getEmail_id() {
		return Email_id;
	}

	public void setEmail_id(String email_id) {
		Email_id = email_id;
	}

	public Date getDOJ() {
		return DOJ;
	}

	public void setDOJ(Date dOJ) {
		DOJ = dOJ;
	}

	public Date getDOB() {
		return DOB;
	}

	public void setDOB(Date dOB) {
		DOB = dOB;
	}

	public String getAddress() {
		return Address;
	}

	public void setAddress(String address) {
		Address = address;
	}

	public String getName() {
		return Name;
	}

	public void setName(String name) {
		Name = name;
	}

	public int getEmployeeId() {
		return EmployeeId;
	}

	public void setEmployeeId(int employeeId) {
		EmployeeId = employeeId;
	}

	public long getPhoneNumber() {
		return PhoneNumber;
	}

	public void setPhoneNumber(long phoneNumber) {
		PhoneNumber = phoneNumber;
	}

	public int getDepartmentId() {
		return DepartmentId;
	}

	public void setDepartmentId(int departmentId) {
		DepartmentId = departmentId;
	}

	public int getRoleId() {
		return RoleId;
	}

	public void setRoleId(int roleId) {
		RoleId = roleId;
	}

	public int getProjectId() {
		return ProjectId;
	}

	public void setProjectId(int projectId) {
		ProjectId = projectId;
	}

	@Override
	public String toString() {

		return EmployeeId+" "+Name  + " " + Email_id + " " + Kin_id+ " " + Address;

	}

}
